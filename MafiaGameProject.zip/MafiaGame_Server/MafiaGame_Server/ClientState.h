#pragma once



enum Job
{
	None,
	Citizen,
	Mafia
};


class ClientState {
	
public:
	int playerIndex;
	char* nickname;
	bool isReady;
	Job job;
	bool isvote;
	bool isDead;
};
